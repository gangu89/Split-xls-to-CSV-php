<?php

include('/var/www/html/test/PHPExcel-1.8/Classes/PHPExcel.php');

 //$filepath = '/var/www/html/test/abcd.xlsx';
 $filepath = '/var/www/html/test/IN_MF_EXPENSE_RATIO_SEBI 21082020.xlsx';
 
 $schemecodesheet_filepath = '/var/www/html/test/scheme_master.xlsx';

if (isset($filepath,$schemecodesheet_filepath)) {

//Regular   
$objPHPExcel = getesheet($filepath);
$regular = $objPHPExcel->getActiveSheet();



$regular->removeRow(1);
$regular->insertNewColumnBefore('A', 1);
$regular->setCellValue('A1', 'Id');
$regular->insertNewColumnBefore('B', 1);
$regular->setCellValue('B1', 'Scheme Code');
$regular->setCellValue('C1', 'Name of Scheme');
$regular->setCellValue('D1', 'Date');


// Want to delete column 
$regular->removeColumnByIndex(9,11);
$regular->UnmergeCells('E1:I1');
$regular->setCellValue('E1', 'Base TER');

$regular->setCellValue('F1', 'Additional expense as per Regulation 52(6A)(b)');
$regular->setCellValue('G1', 'Additional expense as per Regulation 52(6A)(c)');
$regular->setCellValue('H1', 'GST');
$regular->setCellValue('I1', 'Total TER');
$regular->UnmergeCells('J1:N1');
$regular->insertNewColumnBefore('J', 1);
$regular->setCellValue('J1', 'Plan type');


//Retail
$retail_objPHPExcel = getesheet($filepath);
$retail = $retail_objPHPExcel->getActiveSheet();
$retail->removeRow(1);
$retail->insertNewColumnBefore('A', 1);
$retail->setCellValue('A1', 'Id');
$retail->insertNewColumnBefore('B', 1);
$retail->setCellValue('B1', 'Scheme Code');
$retail->setCellValue('C1', 'Name of Scheme');
$retail->setCellValue('D1', 'Date');
// Want to delete column 
$retail->removeColumnByIndex(4,10);
$retail->UnmergeCells('E1:I1');
$retail->setCellValue('E1', 'Base TER');
$retail->setCellValue('F1', 'Additional expense as per Regulation 52(6A)(b)');
$retail->setCellValue('G1', 'Additional expense as per Regulation 52(6A)(c)');
$retail->setCellValue('H1', 'GST');
$retail->setCellValue('I1', 'Total TER');
$retail->UnmergeCells('J1:N1');
$retail->insertNewColumnBefore('J', 1);
$retail->setCellValue('J1', 'Plan type');


//Direct
$direct_objPHPExcel = getesheet($filepath);
$direct = $direct_objPHPExcel->getActiveSheet();
$direct->removeRow(1);
$direct->insertNewColumnBefore('A', 1);
$direct->setCellValue('A1', 'Id');
$direct->insertNewColumnBefore('B', 1);
$direct->setCellValue('B1', 'Scheme Code');
$direct->setCellValue('C1', 'Name of Scheme');
$direct->setCellValue('D1', 'Date');
// Want to delete column 
$direct->removeColumnByIndex(4,5);
$direct->UnmergeCells('E1:I1');
$direct->setCellValue('E1', 'Base TER');
$direct->setCellValue('F1', 'Additional expense as per Regulation 52(6A)(b)');
$direct->setCellValue('G1', 'Additional expense as per Regulation 52(6A)(c)');
$direct->setCellValue('H1', 'GST');
$direct->setCellValue('I1', 'Total TER');
//$direct->UnmergeCells('J1:N1');
$direct->insertNewColumnBefore('J', 1);
$direct->setCellValue('J1', 'Plan type');

$direct->removeColumn('I1');
$direct->removeColumn('J1');
$direct->removeColumn('K1');
$direct->removeColumn('L1');
$direct->removeColumn('M1');
$direct->removeColumn('N1');

echo $highestRow = $objPHPExcel->getActiveSheet()->getHighestRow()-8;
$remve_row_data_count = $objPHPExcel->getActiveSheet()->getHighestRow();

$rem = Removerow_data($remve_row_data_count);
foreach($rem as $rk =>$rv){
    $regular->removeRow($rv);
    $direct->removeRow($rv);
    $retail->removeRow($rv);
}

$res = GenerateID($highestRow);
foreach($res as $k =>$v){
    $regular->setCellValue('A'.$k, $v);
    $direct->setCellValue('A'.$k, $v);
    $retail->setCellValue('A'.$k, $v);
    
    $regular->setCellValue('J'.$k, 'Regular');
    $direct->setCellValue('J'.$k, 'Direct');
    $retail->setCellValue('J'.$k, 'Retail');

   // $regular->setCellValue('B'.$k, $v);
}

//This is schemecode
$get_scheme_code_regular = getscheme_code($filepath,$regular,$schemecodesheet_filepath);
$get_scheme_code_retail = getscheme_code($filepath,$retail,$schemecodesheet_filepath);
$get_scheme_code_direct = getscheme_code($filepath,$direct,$schemecodesheet_filepath);


    

//Output_TER_Regular XLS
$Regular_xls_file_name = "Output_TER_Regular.xls";
$output_ter_regular_xls = GenerateXLS($objPHPExcel,$Regular_xls_file_name);
//echo '<pre>';print_r($output_ter_regular_xls);exit;

//Output_TER_Direct XLS
$Direct_xls_file_name = "Output_TER_Direct.xls";
GenerateXLS($direct_objPHPExcel,$Direct_xls_file_name);

//Output_TER_Retail XLS
$Retail_xlx_file_name = "Output_TER_Retail.xls";
GenerateXLS($retail_objPHPExcel,$Retail_xlx_file_name);




 echo "...File is ok".'<br/>';
//  $xls_file_name_email = basename($filepath);  
//  $sender = 'pankaj.sharma@robosoftin.com';
//  $recipient = 'pankaj.sharma@robosoftin.com';

//  $subject = "php mail test";
//  $message = "Generate $xls_file_name_email file please check Inbox or Spam folder Local";
//  $headers = 'From:' . $sender;

//  if (mail($recipient, $subject, $message, $headers))
//  {
//      echo "Email sent successfully".'<br/>';
//  }
//  else
//  {
//      echo "Email could not be sent".'<br/>';
//  }

 // CSV

$Regular_file_out = "Output_TER_Regular.xls";
$retail_file_out = "Output_TER_Retail.xls";
$direct_file_out = "Output_TER_Direct.xls";

//Output_TER_Regular CSV
$Regular_csv_file = "Output_TER_Regular.csv";
convertXLStoCSV($Regular_file_out,$Regular_csv_file);

// //Output_TER_Direct CSV
$direct_csv_file = "Output_TER_Direct.csv";
convertXLStoCSV($direct_file_out,$direct_csv_file);

//Output_TER_Retail CSV
$Retail_csv_file = "Output_TER_Retail.csv";
convertXLStoCSV($retail_file_out,$Retail_csv_file);

}

function Removerow_data($remve_row_data_count){
    $start = 54;
    $values = array();
    for($row = 54; $row <= $remve_row_data_count; $row++) {
        $values[$row]  =  $start;
    $start++;
    }
    return $values;
}

function getesheet($filepath){
    $objPHPExcel = PHPExcel_IOFactory::load($filepath);
    return $objPHPExcel;
    
}


function GenerateID($highestRow)
{
    $start = 1;
    $values = array();
    for($row = 2; $row <= $highestRow; $row++) {
        $values[$row]  =  $start;
    $start++;
    }
    return $values;
}

function GenerateXLS($GenerateXLS_file,$xls_file_name)
{
    $writer = PHPExcel_IOFactory::createWriter($GenerateXLS_file, 'Excel5');
    $xls_file_out = $xls_file_name; 
    $writer->save($xls_file_out);
}

function convertXLStoCSV($infile,$outfile)
{
    $fileType = PHPExcel_IOFactory::identify($infile);
    $objReader = PHPExcel_IOFactory::createReader($fileType);
 
    $objReader->setReadDataOnly(true);   
    $objPHPExcel = $objReader->load($infile);   


    $totalrows=$objPHPExcel->setActiveSheetIndex(0)->getHighestRow(); //Count Numbe of rows avalable in excel
    $totalcloumn=$objPHPExcel->setActiveSheetIndex(0)->getHighestColumn(); //Count Numbe of rows avalable in excel
    $objWorksheet=$objPHPExcel->setActiveSheetIndex(0);
    //loop from first data untill last data  
    for($i=2;$i<=$totalrows;$i++)
    {
        
    $field0= $objWorksheet->getCellByColumnAndRow(1,$i)->getValue(); //Excel Column 1
    $field1 = $objWorksheet->getCellByColumnAndRow(2,$i)->getValue(); //Excel Column 2
    $field2 = $objWorksheet->getCellByColumnAndRow(3,$i)->getFormattedValue(); //Excel Column 3
    $field2 = PHPExcel_Style_NumberFormat::toFormattedString($field2, "DD/MM/YYYY"); 
    $objWorksheet->setCellValue('D'.$i,$field2);


    $objPHPExcel->getActiveSheet()->getStyle(E.$i)->getNumberFormat()->setFormatCode( PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00 );  //Excel Column 4
    $objPHPExcel->getActiveSheet()->getStyle(F.$i)->getNumberFormat()->setFormatCode( PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00 ); //Excel Column 5
    $objPHPExcel->getActiveSheet()->getStyle(G.$i)->getNumberFormat()->setFormatCode( PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00 ); //Excel Column 6
    $objPHPExcel->getActiveSheet()->getStyle(H.$i)->getNumberFormat()->setFormatCode( PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00 ); //Excel Column 7
    $objPHPExcel->getActiveSheet()->getStyle(I.$i)->getNumberFormat()->setFormatCode( PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00 ); //Excel Column 8   
  
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'CSV');
    $objWriter->save($outfile);
    }
  
}

function getschemecodesheet($schemecodesheet_filepath){
    $objPHPExcel = PHPExcel_IOFactory::load($schemecodesheet_filepath);
    return $objPHPExcel;
    
}


function getscheme_code($filepath,$types_data,$schemecodesheet_filepath){


$schemecodesheet_filepath = $schemecodesheet_filepath;
$schemecodesheet_objPHPExcel = getschemecodesheet($schemecodesheet_filepath);
//echo '<pre>';print_r($schemecodesheet_objPHPExcel);  
$schemecodesheet_totalrows=$schemecodesheet_objPHPExcel->setActiveSheetIndex(0)->getHighestRow(); //Count Numbe of rows avalable in excel
$schemecodesheet_totalcloumn=$schemecodesheet_objPHPExcel->setActiveSheetIndex(0)->getHighestColumn(); //Count Numbe of rows avalable in excel
$schemecodesheet_objWorksheet=$schemecodesheet_objPHPExcel->setActiveSheetIndex(0);
// echo '<br/>' .$schemecodesheet_totalrows;exit;
$scheme_name = array();                 
        for($i=2;$i<=$schemecodesheet_totalrows;$i++)
        {
            $schemecodesheet_scheme_code = $schemecodesheet_objWorksheet->getCellByColumnAndRow(2,$i )->getValue();; //Excel Column 0
            $schemecodesheet_scheme_name = $schemecodesheet_objWorksheet->getCellByColumnAndRow(5,$i)->getValue(); //Excel Column 1  
            $scheme_code[$schemecodesheet_scheme_code]  = $schemecodesheet_scheme_name ;
        //    echo '<pre>';print_r($schemecodesheet_scheme_code.'>>>'.$i);               
        }
$objPHPExcel =  getesheet($filepath);
$remove_row = $objPHPExcel->getActiveSheet();

$remove_row->removeRow(1);
$totalrows=$objPHPExcel->setActiveSheetIndex(0)->getHighestRow()-8; //Count Numbe of rows avalable in excel
$totalcloumn=$objPHPExcel->setActiveSheetIndex(0)->getHighestColumn(); //Count Numbe of rows avalable in excel
$objWorksheet=$objPHPExcel->setActiveSheetIndex(0);
        $scheme_name = array();                 
        for($i=2;$i<=$totalrows;$i++)
        {            
            $scheme_name = $objWorksheet->getCellByColumnAndRow(0,$i)->getValue(); //Excel Column 2  
            $scheme_name = str_replace('Axis Midcap Fund','Axis Mid cap Fund',$scheme_name);
            $scheme_name = str_replace("Axis Children's Gift Fund",'Axis Childrens Gift Fund - No Lock-In',$scheme_name);
            $scheme_name = str_replace("Axis Emerging Opportunities Fund - Series 1 (1400 Days)",'Axis Emerging Opportunities Fund – Series 1 (1400 Days)',$scheme_name);
            $scheme_name = str_replace("Axis Emerging Opportunities Fund - Series 2 (1400 Days)",'Axis Emerging Opportunities Fund – Series 2 (1400 Days)',$scheme_name);
            $scheme_name_data = str_replace("'", '', strtolower($scheme_name));
            
            $data = array_search($scheme_name_data, array_map('strtolower', $scheme_code));         
            // echo '<pre>';print_r($scheme_name_data);
            // echo '<br/>';
            // echo '<pre>';print_r($scheme_code);
                        if(!$data){
                           // echo '<pre>';print_r($data);
                            $data = 'NULL';                         
                        }  
        $types_data->setCellValue('B'.$i ,$data); 
       
    }   //exit;
        return ;

}