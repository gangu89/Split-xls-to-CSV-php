<?php

include('/var/www/html/PHPExcel-1.8/Classes/PHPExcel.php');

 $filepath = '/var/www/html/IN_MF_EXPENSE_RATIO_SEBI 06072020.xlsx';

if (isset($filepath)) {

//Regular   
$objPHPExcel = getesheet($filepath);
$regular = $objPHPExcel->getActiveSheet();


$regular->removeRow(1);
$regular->insertNewColumnBefore('A', 1);
$regular->setCellValue('A1', 'Id');
$regular->setCellValue('B1', 'Name of Scheme');
$regular->setCellValue('C1', 'Date');
// Want to delete column 
$regular->removeColumnByIndex(8,11);
$regular->UnmergeCells('D1:H1');
$regular->setCellValue('D1', 'Base TER');
$regular->setCellValue('E1', 'Additional expense as per Regulation 52(6A)(b)');
$regular->setCellValue('F1', 'Additional expense as per Regulation 52(6A)(c)');
$regular->setCellValue('G1', 'GST');
$regular->setCellValue('H1', 'Total TER');
$regular->UnmergeCells('I1:M1');
$regular->insertNewColumnBefore('I', 1);
$regular->setCellValue('I1', 'Plan type');


//Retail
$retail_objPHPExcel = getesheet($filepath);
$retail = $retail_objPHPExcel->getActiveSheet();
$retail->removeRow(1);
$retail->insertNewColumnBefore('A', 1);
$retail->setCellValue('A1', 'Id');
$retail->setCellValue('B1', 'Name of Scheme');
$retail->setCellValue('C1', 'Date');
// $highestRow = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow()-8; 
// $objPHPExcel->getActiveSheet()->getStyle('C2:C'.$highestRow)->getNumberFormat()->setFormatCode('m/d/yyyy');

// Want to delete column 
$retail->removeColumnByIndex(3,10);
$retail->UnmergeCells('D1:H1');
$retail->setCellValue('D1', 'Base TER');
$retail->setCellValue('E1', 'Additional expense as per Regulation 52(6A)(b)');
$retail->setCellValue('F1', 'Additional expense as per Regulation 52(6A)(c)');
$retail->setCellValue('G1', 'GST');
$retail->setCellValue('H1', 'Total TER');
$retail->UnmergeCells('I1:M1');
$retail->insertNewColumnBefore('I', 1);
$retail->setCellValue('I1', 'Plan type');


//Direct
$direct_objPHPExcel = getesheet($filepath);
$direct = $direct_objPHPExcel->getActiveSheet();
$direct->removeRow(1);
$direct->insertNewColumnBefore('A', 1);
$direct->setCellValue('A1', 'Id');
$direct->setCellValue('B1', 'Name of Scheme');
$direct->setCellValue('C1', 'Date');
// Want to delete column 
$direct->removeColumnByIndex(3,5);
$direct->UnmergeCells('D1:H1');
$direct->setCellValue('D1', 'Base TER');
$direct->setCellValue('E1', 'Additional expense as per Regulation 52(6A)(b)');
$direct->setCellValue('F1', 'Additional expense as per Regulation 52(6A)(c)');
$direct->setCellValue('G1', 'GST');
$direct->setCellValue('H1', 'Total TER');
$direct->UnmergeCells('I1:M1');
$direct->insertNewColumnBefore('I', 1);
$direct->setCellValue('I1', 'Plan type');

$direct->removeColumn('H1');
$direct->removeColumn('I1');
$direct->removeColumn('J1');
$direct->removeColumn('K1');
$direct->removeColumn('L1');
$direct->removeColumn('M1');

echo $highestRow = $objPHPExcel->getActiveSheet()->getHighestRow()-8;
$remve_row_data_count = $objPHPExcel->getActiveSheet()->getHighestRow();

$rem = Removerow_data($remve_row_data_count);
foreach($rem as $rk =>$rv){
    $regular->removeRow($rv);
    $direct->removeRow($rv);
    $retail->removeRow($rv);
}

$res = GenerateID($highestRow);
foreach($res as $k =>$v){
    $regular->setCellValue('A'.$k, $v);
    $direct->setCellValue('A'.$k, $v);
    $retail->setCellValue('A'.$k, $v);
    
    $regular->setCellValue('I'.$k, 'Regular');
    $direct->setCellValue('I'.$k, 'Direct');
    $retail->setCellValue('I'.$k, 'Retail');
}

//Output_TER_Regular XLS
$Regular_xls_file_name = "Output_TER_Regular.xls";
GenerateXLS($objPHPExcel,$Regular_xls_file_name);


//Output_TER_Direct XLS
$Direct_xls_file_name = "Output_TER_Direct.xls";
GenerateXLS($direct_objPHPExcel,$Direct_xls_file_name);

//Output_TER_Retail XLS
$Retail_xlx_file_name = "Output_TER_Retail.xls";
GenerateXLS($retail_objPHPExcel,$Retail_xlx_file_name);


 echo "...File is ok";

 // CSV

$Regular_file_out = "Output_TER_Regular.xls";
$retail_file_out = "Output_TER_Retail.xls";
$direct_file_out = "Output_TER_Direct.xls";

//Output_TER_Regular CSV
$Regular_csv_file = "Output_TER_Regular.csv";
convertXLStoCSV($Regular_file_out,$Regular_csv_file);

// //Output_TER_Direct CSV
$direct_csv_file = "Output_TER_Direct.csv";
convertXLStoCSV($direct_file_out,$direct_csv_file);

//Output_TER_Retail CSV
$Retail_csv_file = "Output_TER_Retail.csv";
convertXLStoCSV($retail_file_out,$Retail_csv_file);

}

function Removerow_data($remve_row_data_count){
    $start = 55;
    $values = array();
    for($row = 55; $row <= $remve_row_data_count; $row++) {
        $values[$row]  =  $start;
    $start++;
    }
    return $values;
}

function getesheet($filepath){
    $objPHPExcel = PHPExcel_IOFactory::load($filepath);
    return $objPHPExcel;
    
}


function GenerateID($highestRow)
{
    $start = 1;
    $values = array();
    for($row = 2; $row <= $highestRow; $row++) {
        $values[$row]  =  $start;
    $start++;
    }
    return $values;
}

function GenerateXLS($GenerateXLS_file,$xls_file_name)
{
    $writer = PHPExcel_IOFactory::createWriter($GenerateXLS_file, 'Excel5');
    $xls_file_out = $xls_file_name;
    $writer->save($xls_file_out);
}

function convertXLStoCSV($infile,$outfile)
{
    $fileType = PHPExcel_IOFactory::identify($infile);
    $objReader = PHPExcel_IOFactory::createReader($fileType);
 
    $objReader->setReadDataOnly(true);   
    $objPHPExcel = $objReader->load($infile);    
 
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'CSV');
    $objWriter->save($outfile);
}